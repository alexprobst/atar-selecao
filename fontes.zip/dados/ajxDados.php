<?php

if (!isset($_SESSION)) {
    session_start();
}

    $op       = isset($_GET['op'])?$_GET['op']:'';
    $pageSize = isset($_GET['pageSize'])?$_GET['pageSize']:'10';
    $nextPage = '';

    switch($op) {

        case '2' : // Reload próxima Página

            $nextPage = $_SESSION["sesNextPage"];

            $json_file = file_get_contents("https://fake-dot-wearatar-dev.appspot.com/profiles?pageSize=$pageSize&page=".$nextPage);

            $json_str = json_decode($json_file, true);
            $nextPage = $json_str['nextPage'];
            $_SESSION["sesNextPage"] = $nextPage;

        break;

        default:
            $json_file = file_get_contents("https://fake-dot-wearatar-dev.appspot.com/profiles?pageSize=$pageSize");
            $json_str = json_decode($json_file, true);
            $nextPage = $json_str['nextPage'];
            $_SESSION["sesNextPage"] = $nextPage;

    }

	$itens = $json_str['profiles'];

    ## Formata dos dados ##
    foreach($itens as $key => $subarray) {

        // Telefone +55 (64) 25509-0018
        $fone = $itens[$key]['phone'];
        $fone = '+' . substr($fone,0,2) . ' ('. substr($fone,3,2) . ') ' . substr($fone,4,5) . '-' . substr($fone,9);

        // Documento
        $cpf = $itens[$key]['document'];
        $cpf = substr($cpf,0,3) . '.' . substr($cpf,3,3) . '.' . substr($cpf,6,3) . '-' . substr($cpf,9);

        //Data Aniversário
        $dtAniv = $itens[$key]['birthDate'];
        $dtAniv = date('d/m/Y',$dtAniv);

        $itens[$key]['phone'] = $fone;
        $itens[$key]['document'] = $cpf;
        $itens[$key]['birthDate'] = $dtAniv ;
    }

    $data['data'] = $itens;
    print_r(json_encode($data));

?>